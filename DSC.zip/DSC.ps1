Configuration Task 
{
    param ($MachineName)

    Import-DscResource -ModuleName PsDesiredStateConfiguration

    Node $MachineName {

        WindowsFeature WebServer {
            Ensure = "Present"
            Name   = "Web-Server"
        }

        WindowsFeature ASP
        {
          Ensure = "Present"
          Name = "Web-Asp-Net45"
        }

    WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }  
    }
}

Configuration Binding
{

$sitename = "Default Web Site" 

Import-DSCResource -ModuleName PSDesiredStateConfiguration 

Import-DSCResource -ModuleName 'xWebAdministration'

xWebsite MainHTTPWebsite  
{  
    Ensure          = "Present"  
    Name            = $sitename
    ApplicationPool = "DefaultAppPool" 
    State           = "Started"  
    PhysicalPath    = "%SystemDrive%\inetpub\wwwroot\iisstart.htm"  
    BindingInfo     =
                        @(MSFT_xWebBindingInformation
                            {
                                Protocol              = "HTTP"
                                Port                  = 8080
                                HostName              = "http://localhost/"
                            }
                        )
}
} 

